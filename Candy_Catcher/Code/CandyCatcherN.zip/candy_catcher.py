# <insert your name here>
# imports
import pgzrun
import random

# create constants
WIDTH = 640
HEIGHT = 480

# create parent class
class game_object:
    def __init__(self,filename):
        self.actor = Actor(filename)
        self.set_position()

    def set_position(self):
        self.actor.top = square * random.randint(0,num_squares_height-1)
        self.actor.right = square * random.randint(0,num_squares_width-1)

    def on_collision(self):
        print("this should be handled by the subclasses")

# create child classes
class candy(game_object):
        def __init__(self,filename):
                super().__init__(filename)

        def on_collision(self):
                self.set_position()
                return "score",1



class bomb(game_object):
        def __init__(self,filename):
                super().__init__(filename)
                
        def on_collision(self):
                self.set_position()
                return "health",1



# make hero
hero = Actor("hero")

# set grid size
square = hero.width
num_squares_width = WIDTH // square
num_squares_height = HEIGHT // square

# create a list of game objects
game_objects = []

# add 5 candies to the game
for i in range(5):
    game_objects.append(candy("candy"))

# add 3 bombs to the game
for i in range(3):
    game_objects.append(bomb("bomb"))

# manage game state
score = 0
health = 5
gameover = False

# read high score from file and set target

# print welcome -- update when high score is added
print("""---------------------------
Welcome to Candy Catcher!
---------------------------
Collect candies (1 point each)
Avoid bombs (3 seconds off timer each)
Reach 20 points to win!
Press arrow keys to move.
---------------------------""")

# manage key controls
def on_key_down(key):
    # down up left right
    if key == keys.DOWN:
        hero.bottom = hero.bottom + square
    if key == keys.UP:
        hero.top = hero.top - square
    if key == keys.LEFT:
        hero.left = hero.left - square
    if key == keys.RIGHT:
        hero.right = hero.right + square

# update everything
def update():
    global score,health,gameover
    # pass
    # stop updating if game is over
    if gameover==True:
        return
    # Check collisions with all game objects (demonstrates polymorphism)
    for i in game_objects:
        if hero.colliderect(i.actor):
            change,value = i.on_collision()
            # behavior depends on object type
            if change=="score":
                score+=value
            else:
                health-=value
            print(f"score:{score} health:{health}")
            # Prevent negative scores
            if health==0:
                gameover=True

    
    # Check win condition
    
    # update timer

# draw everything to screen
def draw():
        # clear screen
        screen.fill("black")
        # draw all game objects (demonstrates polymorphism)
        for i in game_objects:
            i.actor.draw()
        # draw hero
        hero.draw()
        # draw text
        screen.draw.text(f'Score: {score}', (10, 10), color="white", fontsize=30)
        screen.draw.text(f'Hearts: {int(health)}/5', (10, 25), color="white", fontsize=30)
   
    
        # update high score file if new high score achieved


# runs everything
pgzrun.go()
