# <insert your name here>
# imports
import random
import pgzrun

# create constants
WIDTH = 640
HEIGHT = 480
SQUARE = 32
NUM_SQUARES_WIDTH = WIDTH // SQUARE
NUM_SQUARES_HEIGHT = HEIGHT // SQUARE

# print welcome
print("""
---------------------------
Welcome to Candy Crunch!
The game is about to start.
Press the arrow keys to move 
and collect the candies.
---------------------------
""")

# make hero
hero = Actor("hero")
# make candy
candy = Actor("candy")
# add candy
candy2 = Actor("candy")
candy3 = Actor("candy")

# add game bits
score = 0

# make timer (extension)


# start candy positions
candy.bottom = random.randint(SQUARE, HEIGHT)
candy.right = random.randint(SQUARE, WIDTH)
candy2.bottom = random.randint(SQUARE, HEIGHT)
candy2.right = random.randint(SQUARE, WIDTH)
candy3.bottom = random.randint(SQUARE, HEIGHT)
candy3.right = random.randint(SQUARE, WIDTH)

# manage key controls
def on_key_down(key):
    # down up left right
    if key == keys.DOWN:
        hero.bottom = hero.bottom + SQUARE
    if key == keys.UP:
        hero.top = hero.top - SQUARE
    if key == keys.LEFT:
        hero.left = hero.left - SQUARE
    if key == keys.RIGHT:
        hero.right = hero.right + SQUARE

    # stay on screen (extension)

# update everything
def update():
    global score
    # check collisions
    if hero.colliderect(candy):
        candy.bottom = random.randint(SQUARE, HEIGHT)
        candy.right = random.randint(SQUARE, WIDTH)
        score = score + 1
    if hero.colliderect(candy2):
        candy2.bottom = random.randint(SQUARE, HEIGHT)
        candy2.right = random.randint(SQUARE, WIDTH)
        score = score + 1
    if hero.colliderect(candy3):
        candy3.bottom = random.randint(SQUARE, HEIGHT)
        candy3.right = random.randint(SQUARE, WIDTH)
        score = score + 1

    # win condition


    # timer (extension)
    

# draw everything to screen
def draw():
    # empty screen
    screen.fill("black")
    # draw candies
    candy.draw()
    candy2.draw()
    candy3.draw()
    # draw hero
    hero.draw()
    # draw text on screen
    x_pos = 300
    y_pos = 10
    screen.draw.text('Score: ' + str(score), (x_pos, y_pos), color=(255,255,255), fontsize=30)

# runs everything
pgzrun.go()
