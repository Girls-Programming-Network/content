# imports
import pgzrun
import random

# set grid size
WIDTH = 640
HEIGHT = 480

# print welcome
print("""---------------------------
Welcome to Candy Catcher!
---------------------------
Collect candies (1 point each)
Avoid bombs (3 seconds off timer each)
Reach 20 points to win!
Press arrow keys to move.
---------------------------""")

# make hero
hero = Actor("hero")

# create constants
square = hero.width
num_square_width = WIDTH // square
num_square_height = HEIGHT // square

# make candies
candy = Actor("candy")

# add candies
def add_candy():
    candy = Actor("candy")
    candies.append(candy)
    candy.top = random.randint(0, num_square_height - 1) * square
    candy.left = random.randint(0, num_square_width - 1) * square


# loop candies
candies = []
for i in range(3):
    add_candy()

# add game bits
win = False 

# make timer
frames = 0
# start candy positions

# manage key controls
def on_key_down(key):
    if win == True:
        return
    # down up left right
    if key == keys.DOWN:
        hero.bottom = min(hero.bottom + square, HEIGHT)
    if key == keys.UP:
        hero.top = max(hero.top - square, 0)    
    if key == keys.LEFT:
        hero.left = max(hero.left - square, 0)
    if key == keys.RIGHT:
        hero.right = min(hero.right + square, WIDTH) 
    

# update everything
def update():
    global frames, win
    # check collisions
    if win == True:
        return
    for candy in candies:
        if hero.colliderect(candy):
            candies.remove(candy)

    # win condition
    if len(candies) == 0:
        print("You won")
        win = True

    # timer
    frames = frames + 1
    # add a new candy
    if frames % 180 == 0:
        add_candy()


    pass    

# draw everything to screen
def draw():
    # empty screen
    screen.fill("black")
    
    # draw candies
    for candy in candies:
        candy.draw()
    # draw hero
    hero.draw()

    # draw text on screen
    if win == True:
        screen.fill("green")
        screen.draw.text(("You won!! "),(0,5),color="white",fontsize=20)
    

# runs everything
pgzrun.go()# Copy your code from the last section here first!
