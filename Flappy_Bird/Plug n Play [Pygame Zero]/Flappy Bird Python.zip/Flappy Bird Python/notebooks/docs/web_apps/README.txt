This is derivative work from https://github.com/stonebig/python-fun
It is tweaked to work with WinPython out of the box, and in parallel

with Flask example, Todo-list pre-include "Flask can do it!", in port http://127.0.0.1:5000
with FastAPI example, Todo-list pre-includes "FastAPI runs !", in port http://127.0.0.1:8000
with Django example, Todo-list pre-includes "Dnajgo lives !", in port http://127.0.0.1:7000 (defaul is 8000, so modified)
