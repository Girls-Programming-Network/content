# <The student's name>
# start modules


# create constants


# print welcome


# make background


# make bird


# make pipes


# draw everything to screen


    # draw background


    # draw characters


# update everything


    # update bird


    # update pipes


    # bird hits bottom of screen


    # bird hits pipes


# moving


# runs everything
